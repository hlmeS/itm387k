import numpy as np
import pandas as pd
import matplotlib as plt 
import datetime
import mysql.connector
from mysql.connector import MySQLConnection, Error

print "Yeah, I have all packages installed already."
